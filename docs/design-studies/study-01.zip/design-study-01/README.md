# Media tracker — editorial design study

An isolated React/Vite prototype exploring an ambitious visual direction for Marqd v2. It does not modify the existing media-tracker application or connect to production data.

## Preview

Run `npm install`, then `npm run dev`. Open http://127.0.0.1:3190.

This workspace currently reuses the existing application's dependencies through a local node_modules symlink. For an independent checkout, install the dependencies declared in package.json instead.

## Design

Cool cloud-white, lavender surfaces, and muted plum accents with expressive serif display typography and a cover collage. Rounded navigation, cards, covers, and detail panels soften the editorial layout. Top navigation replaces the persistent sidebar. Responsive two-column mobile collection; native modal focus handling; keyboard controls; reduced-motion support.

## Interactive scope

For you, Collection, Journal; title search and media filters; item details; collection membership, favorite toggle, whole-star demo ratings, progress, and journal notes. Changes last for the current browser session in memory only and reset on reload. Search filters six bundled samples, not external catalogs. Production half-star ratings and provider-specific progress are outside this design spike.

Artwork comes from the existing project's sample catalog (Open Library, TMDB, Steam). Fonts are loaded from Google Fonts. This prototype requires internet access for those assets. A production/homelab implementation should address asset hosting and provider attribution/terms before release.

## Validation

Production build passed. Browser checks verified desktop rendering, modal rating/notes/progress edits, collection book filtering, and a 390px-wide mobile collection with no horizontal overflow. This is not a production performance benchmark.

## Appearance settings

Terracotta is the default palette. The header Settings button opens a native dialog with thirteen palettes, including Rosewater, Sandstone, and Midnight. Selection updates every screen immediately and persists by palette name in this browser's localStorage (`marqd.palette`). Missing or unknown preferences fall back to Terracotta. Storage failures show a session-only notice. Reset to Terracotta restores and saves the default. This is browser-local preference storage, not account synchronization.
