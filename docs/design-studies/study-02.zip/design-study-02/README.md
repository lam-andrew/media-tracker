# Marqd — Design Study 02: A room of your own

A separate, exploratory React prototype. It does not replace Study 01 or modify the production app.

## Direction

A softly lit, spatial library with terracotta accents, frosted controls, dimensional media jackets and spines, and daylight/evening lighting. Pointer hover or keyboard focus reveals a cover; click opens details. Previous/next controls support touch browsing. Gallery offers a conventional scan-friendly alternative; Journal displays notes.

This is a visual shelf experiment, not a committed production shelf feature. Film, TV, and game cases are provisional representations. No WebGL or animation library: transitions and depth use CSS. Reduced-motion preferences disable animations and transitions.

## References

- [Applebee — Admiral Studios](https://dribbble.com/shots/27179977-Applebee-Immersive-Reading-App-Interface): spatial composition, soft lighting, frosted floating controls.
- [Illustrated Editions — Taras Oliinyk](https://dribbble.com/shots/27627707-Illustrated-Editions-Bookstore-Landing-Page): interactive spines, quiet editorial typography, tactile browsing.

The references were inspected visually. This implementation is original code; no reference screenshots or videos are embedded. Covers come from the existing project's Open Library, TMDB and Steam sample catalog. Google Fonts supplies DM Sans and Instrument Serif. Attribution, font hosting, and image-provider terms need production review.

## Preview

`npm install` then `npm run dev` at http://127.0.0.1:3192/.

This workspace currently uses a node_modules symlink to the existing media-tracker dependencies. Install the declared dependencies for an independent checkout. Build with `npm run build`.

## Scope and verification

Six sample titles, local filtering, room/gallery/journal navigation, rating, notes, favorites, collection membership, and percentage progress. Edits and lighting mode are in-memory and reset on reload. No backend, authentication, real search, or account changes. Whole-star ratings and generic percentage progress are prototype simplifications.

Build and TypeScript checks passed. Browser verification covered next-story selection, detail dialog, rating update, progress update propagating to the room, note editing, and evening mode. At 390px, content width equaled viewport width (no horizontal overflow).
