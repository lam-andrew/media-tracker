export const media = [
{id:1,title:'Dune',creator:'Frank Herbert',type:'Books',image:'https://covers.openlibrary.org/b/id/11481354-L.jpg',color:'#bd653d',caption:'A world worth getting lost in.',description:'Politics, prophecy, and survival on the desert planet Arrakis. A story about the futures we imagine—and the power it takes to shape them.',progress:42,rating:5},
{id:2,title:'Severance',creator:'Dan Erickson · 2022',type:'TV',image:'https://image.tmdb.org/t/p/w500/pPHpeI2X1qEd1CS1SeyrdhZ4qnT.jpg',color:'#758b9b',caption:'Leave your other self at the door.',description:'An office where work and personal memories are surgically divided. A beautifully unsettling mystery about identity, control, and what makes a life your own.',progress:44,rating:4},
{id:3,title:'Spirited Away',creator:'Hayao Miyazaki · 2001',type:'Movies',image:'https://image.tmdb.org/t/p/w500/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg',color:'#97a290',caption:'Some worlds never leave you.',description:'A young girl finds herself in a spirit world and must summon her courage to rescue her parents. A tender, strange, unforgettable adventure.',progress:100,rating:5},
{id:4,title:'Hades',creator:'Supergiant Games · 2020',type:'Games',image:'https://cdn.cloudflare.steamstatic.com/steam/apps/1145360/library_600x900.jpg',color:'#b94435',caption:'One more escape attempt.',description:'Defy the god of the dead in a mythological underworld where every escape attempt brings a new story—and another reason to return.',progress:62,rating:5},
{id:5,title:'Blade Runner 2049',creator:'Denis Villeneuve · 2017',type:'Movies',image:'https://image.tmdb.org/t/p/w500/gajva2L0rPYkEWjzgFlBXCAVBE5.jpg',color:'#d97545',caption:'What does it mean to be human?',description:'A new blade runner uncovers a secret that sends him searching for a missing predecessor. A quiet, monumental science-fiction journey through memory and belonging.',progress:0,rating:0},
{id:6,title:'Circe',creator:'Madeline Miller',type:'Books',image:'https://covers.openlibrary.org/b/id/8739376-L.jpg',color:'#b58d43',caption:'A myth, finally in her own words.',description:'An exiled goddess discovers her power on an isolated island. An intimate reimagining of Greek mythology, transformation, and independence.',progress:23,rating:4},
];
export type Item=typeof media[number];

export const palettes = [
{name:'Rosewater', mood:'Soft · rosy · delicate', colors:['#fff8f8','#f5e7ea','#fffdfd','#49313c','#80616f','#e8d1d9','#ab5678','#ffffff']},
{name:'Sandstone', mood:'Natural · sandy · understated', colors:['#faf8f3','#eee9de','#ffffff','#38362f','#736f61','#dcd5c5','#756648','#ffffff']},
{name:'Midnight', mood:'Dark · inky · blue', colors:['#171d2d','#202a3d','#2c3850','#f0f3fc','#afbdd6','#414f6a','#aac1f1','#1a2944']},
{name:'Porcelain', mood:'Crisp · neutral · gallery', colors:['#fafafa','#efefef','#ffffff','#252525','#626262','#dcdcdc','#303030','#ffffff']},
{name:'Coastal', mood:'Airy · blue · fresh', colors:['#f5f9fc','#e5eef6','#ffffff','#20394d','#52697b','#cfdee9','#356f98','#ffffff']},
{name:'Terracotta', mood:'Warm · earthy · tactile', colors:['#fcf7f2','#f1e4da','#fffcf8','#45332c','#796258','#dfcbbd','#a94e36','#ffffff']},
{name:'Matcha', mood:'Calm · botanical · soft', colors:['#f7f9f4','#e8eddf','#ffffff','#2f3c2b','#64705a','#d1dbc5','#587144','#ffffff']},
{name:'Cherry', mood:'Clean · confident · vivid', colors:['#fcf8f7','#f4e8e6','#ffffff','#392c30','#78636a','#e8d5d8','#b73750','#ffffff']},
{name:'Cobalt', mood:'Bright · graphic · electric', colors:['#f8f9fd','#e9edf7','#ffffff','#202b49','#5a6784','#d5dcee','#3156ce','#ffffff']},
{name:'Apricot', mood:'Sunny · gentle · playful', colors:['#fffaf3','#f9ecd9','#ffffff','#4c3826','#7b654d','#ebd8bf','#e6ae75','#412c1b']},
{name:'Graphite', mood:'Dark · quiet · minimal', colors:['#191b1e','#22252a','#2c3036','#f1f2f4','#afb5bf','#3d434c','#d3d9e3','#222730']},
{name:'Deep sea', mood:'Dark · immersive · teal', colors:['#112329','#193139','#23404a','#edf6f5','#a9c3c7','#35545d','#8bcac2','#122e32']},
{name:'Espresso', mood:'Dark · warm · intimate', colors:['#251e1b','#302722','#3d322c','#f6eee5','#c2afa0','#514139','#dab393','#33241c']},
];
